﻿// 1_STL_PREVIEW1
#include <iostream>
#include <list>

int main()
{
	std::list<int> s;
}
